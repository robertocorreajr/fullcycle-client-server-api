package app

// DollarQuoteDTO representa a cotação do dólar
type DollarQuoteDTO struct {
	Bid string `json:"bid"`
}
